prompt --application/user_interfaces
begin
--   Manifest
--     USER INTERFACES: 99825
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_shared.create_user_interface(
 p_id=>wwv_flow_imp.id(99825)
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_login_url=>'f?p=&APP_ID.:0:&APP_SESSION.::&DEBUG.:::'
,p_theme_style_by_user_pref=>false
,p_built_with_love=>false
,p_navigation_list_id=>wwv_flow_imp.id(38671065569374286769)
,p_navigation_list_position=>'SIDE'
,p_navigation_list_template_id=>wwv_flow_imp.id(38671629706976286847)
,p_nav_list_template_options=>'#DEFAULT#:js-defaultCollapsed:js-navCollapsed--hidden:t-TreeNav--classic'
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(38671754815844286973)
,p_nav_bar_list_template_id=>wwv_flow_imp.id(38671629387842286847)
,p_nav_bar_template_options=>'#DEFAULT#'
);
wwv_flow_imp.component_end;
end;
/
