prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(38671754815844286973)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>15569650619020
);
wwv_flow_imp.component_end;
end;
/
