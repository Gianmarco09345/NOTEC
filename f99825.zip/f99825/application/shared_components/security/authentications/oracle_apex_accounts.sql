prompt --application/shared_components/security/authentications/oracle_apex_accounts
begin
--   Manifest
--     AUTHENTICATION: Oracle APEX Accounts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(38671064706228286768)
,p_name=>'Oracle APEX Accounts'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'USER_AUTH_FUNC'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>15569592731936
);
wwv_flow_imp.component_end;
end;
/
