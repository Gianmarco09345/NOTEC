prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Calendar'
,p_alias=>'CALENDAR'
,p_step_title=>'Calendar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38771789395080799147)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38671180744641286822)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38671065047146286768)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38671643540780286855)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38771790053231799148)
,p_plug_name=>'Calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38671168358422286816)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return q''~',
'select ID,',
'       NAME,',
'       DATE_START,',
'       DATE_END,',
'       TASK,',
'       CASE TASK',
'            WHEN ''Objetivos'' THEN ''apex-cal-green fa fa-bullseye''',
'            WHEN ''Tareas'' THEN ''apex-cal-blue fa fa-tasks''',
'            WHEN ''Clases'' THEN ''apex-cal-red fa fa-book''',
'            WHEN ''Estudio'' THEN ''apex-cal-yellow fa fa-pencil''',
'            WHEN ''Recordatorios'' THEN ''apex-cal-orange fa fa-bell''',
'            ELSE ''apex-cal-default''',
'        END AS css_class',
'  from CALENDAR',
'~'';'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'display_column', 'ID',
  'end_date_column', 'DATE_END',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_START')).to_clob
);
wwv_flow_imp.component_end;
end;
/
