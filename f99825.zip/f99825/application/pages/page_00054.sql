prompt --application/pages/page_00054
begin
--   Manifest
--     PAGE: 00054
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_page.create_page(
 p_id=>54
,p_name=>'Quizz'
,p_alias=>'QUIZZ1'
,p_page_mode=>'MODAL'
,p_step_title=>'Quizz'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(38953319541441108538)
,p_name=>'Quizz'
,p_template=>wwv_flow_imp.id(38671168358422286816)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'QUIZ_QUESTIONS'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(38671606772801286835)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953321103825108661)
,p_query_column_id=>1
,p_column_alias=>'QUESTION_ID'
,p_column_display_sequence=>0
,p_column_heading=>'Question ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953321633039108662)
,p_query_column_id=>2
,p_column_alias=>'QUESTION_TEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Question Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953322018628108662)
,p_query_column_id=>3
,p_column_alias=>'OPTION_1'
,p_column_display_sequence=>3
,p_column_heading=>'Option 1'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<input type="radio" name="q_#QUESTION_ID#" value="1"> #OPTION_1#',
''))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953322473876108662)
,p_query_column_id=>4
,p_column_alias=>'OPTION_2'
,p_column_display_sequence=>4
,p_column_heading=>'Option 2'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<input type="radio" name="q_#QUESTION_ID#" value="2"> #OPTION_2#',
''))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953322825374108662)
,p_query_column_id=>5
,p_column_alias=>'OPTION_3'
,p_column_display_sequence=>5
,p_column_heading=>'Option 3'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<input type="radio" name="q_#QUESTION_ID#" value="3"> #OPTION_3#',
''))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953323298180108663)
,p_query_column_id=>6
,p_column_alias=>'OPTION_4'
,p_column_display_sequence=>6
,p_column_heading=>'Option 4'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<input type="radio" name="q_#QUESTION_ID#" value="4"> #OPTION_4#',
''))
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953323602183108663)
,p_query_column_id=>7
,p_column_alias=>'CORRECT_OPTION'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38953324031264108663)
,p_query_column_id=>8
,p_column_alias=>'USER_ANSWER'
,p_column_display_sequence=>8
,p_column_heading=>'User Answer'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38862080157913568347)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38953319541441108538)
,p_button_name=>'Submit_quizz'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38671641931205286854)
,p_button_image_alt=>'Submit Quizz'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38862080289057568348)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Quizz'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    FOR i IN 1..apex_application.g_f01.COUNT LOOP',
'        DECLARE',
'            l_selected_option NUMBER;',
'        BEGIN',
'            -- Get the selected option',
'            l_selected_option := TO_NUMBER(apex_application.g_f01(i));',
'',
'            -- Insert into quiz_results',
'            INSERT INTO quiz_results (user_id, question_id, selected_option, is_correct)',
'            VALUES (:APP_USER, -- Assuming :APP_USER is a VARCHAR2 user identifier',
'                    apex_application.g_f02(i), -- Assuming g_f02 contains question IDs',
'                    l_selected_option,',
'                    CASE ',
'                        WHEN l_selected_option = (SELECT correct_option FROM quiz_questions WHERE question_id = apex_application.g_f02(i))',
'                        THEN 1 ELSE 0',
'                    END);',
'        END;',
'    END LOOP;',
'    COMMIT;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38862080289057568348
);
wwv_flow_imp.component_end;
end;
/
