prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Notas'
,p_alias=>'NOTAS'
,p_step_title=>'Notas'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function openTab(event, tabId) {',
unistr('    // Ocultar todo el contenido de las pesta\00F1as'),
'    var tabContents = document.getElementsByClassName(''tab-content'');',
'    for (var i = 0; i < tabContents.length; i++) {',
'        tabContents[i].style.display = ''none'';',
'    }',
'',
'    // Eliminar la clase "active" de todos los botones',
'    var tabButtons = document.getElementsByClassName(''tab-button'');',
'    for (var i = 0; i < tabButtons.length; i++) {',
'        tabButtons[i].className = tabButtons[i].className.replace('' active'', '''');',
'    }',
'',
unistr('    // Mostrar el contenido de la pesta\00F1a seleccionada'),
'    document.getElementById(tabId).style.display = ''block'';',
'',
unistr('    // A\00F1adir la clase "active" al bot\00F3n clicado'),
'    event.currentTarget.className += '' active'';',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38763159229012847549)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38671180744641286822)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(38671065047146286768)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38671643540780286855)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38852331362617481220)
,p_plug_name=>'New'
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="tabs">',
'    <button type="button" class="tab-button active" onclick="openTab(event, ''tab1'')">Notas</button>',
'    <button type="button" class="tab-button" onclick="openTab(event, ''tab2'')">Tareas</button>',
'</div>',
'',
'<div id="tab1" class="tab-content" style="display: block;">',
unistr('    <h2>Contenido de la Pesta\00F1a 1</h2>'),
unistr('    <p>Este es el contenido de la primera pesta\00F1a.</p>'),
'</div>',
'',
'<div id="tab2" class="tab-content" style="display: none;">',
unistr('    <h2>Contenido de la Pesta\00F1a 2</h2>'),
unistr('    <p>Este es el contenido de la segunda pesta\00F1a.</p>'),
'</div>',
'',
unistr('<!-- Estilos CSS para las pesta\00F1as -->'),
'<style>',
'    .tabs {',
'        display: flex;',
'        justify-content: flex-start;',
'        margin-bottom: 20px;',
'    }',
'    .tab-button {',
'        background-color: transparent;',
'        border: none;',
'        padding: 10px 20px;',
'        cursor: pointer;',
'        outline: none;',
'        transition: background-color 0.3s;',
'    }',
'    .tab-button.active {',
'        background-color: #555;',
'        color: white;',
'    }',
'    .tab-content {',
'        display: none;',
'    }',
'</style>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(38971795310355639002)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(38671168358422286816)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'NOTES'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(38671606772801286835)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795416572639003)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795555604639004)
,p_query_column_id=>2
,p_column_alias=>'USER_ID'
,p_column_display_sequence=>20
,p_column_heading=>'User Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795647111639005)
,p_query_column_id=>3
,p_column_alias=>'TITLE'
,p_column_display_sequence=>30
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795743866639006)
,p_query_column_id=>4
,p_column_alias=>'CONTENT'
,p_column_display_sequence=>40
,p_column_heading=>'Content'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795857517639007)
,p_query_column_id=>5
,p_column_alias=>'CREATED_AT'
,p_column_display_sequence=>50
,p_column_heading=>'Created At'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971795921936639008)
,p_query_column_id=>6
,p_column_alias=>'UPDATED_AT'
,p_column_display_sequence=>60
,p_column_heading=>'Updated At'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971796000063639009)
,p_query_column_id=>7
,p_column_alias=>'VIEW_NOTE'
,p_column_display_sequence=>70
,p_column_heading=>'View Note'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971796182507639010)
,p_query_column_id=>8
,p_column_alias=>'UPDATE_NOTE'
,p_column_display_sequence=>80
,p_column_heading=>'Update Note'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971796237554639011)
,p_query_column_id=>9
,p_column_alias=>'ERASE_NOTE'
,p_column_display_sequence=>90
,p_column_heading=>'Erase Note'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38971796393347639012)
,p_query_column_id=>10
,p_column_alias=>'CATEGORY'
,p_column_display_sequence=>100
,p_column_heading=>'Category'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38734356741931161931)
,p_button_sequence=>10
,p_button_name=>'Note'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38671641248706286854)
,p_button_image_alt=>'Note'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::P6_CATEGORY_NAME,P6_USERNAME:&P6_CATEGORY_NAME.,:AUTH_USER.'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38852332466094481231)
,p_name=>'P6_CATEGORY_NAME'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
