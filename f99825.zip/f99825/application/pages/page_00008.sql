prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Pomodoro'
,p_alias=>'POMODORO'
,p_step_title=>'Pomodoro'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var pomodoroInterval;',
'var isRunning = false;',
unistr('var durationInMinutes = 25; // Duraci\00F3n inicial en minutos'),
'var totalTime = durationInMinutes * 60; // Convertir a segundos',
unistr('var breakTime = 5 * 60; // Duraci\00F3n del descanso en segundos (por defecto 5 minutos)'),
'',
'// Mostrar el tiempo inicial en el div',
'document.getElementById("pomodoro-timer").textContent = formatTime(totalTime);',
'document.getElementById("pomodoro-status").textContent = "Tiempo de estudio"; // Mostrar estado inicial',
'',
unistr('// Funci\00F3n para actualizar la duraci\00F3n de la sesi\00F3n'),
'function updateDuration() {',
unistr('    if (!isRunning) { // Solo permite cambiar si el temporizador no est\00E1 en marcha'),
'        var selectElement = document.getElementById("session-time");',
'        durationInMinutes = parseInt(selectElement.value); // Obtener el valor seleccionado',
'        totalTime = durationInMinutes * 60; // Convertir a segundos',
'        document.getElementById("pomodoro-timer").textContent = formatTime(totalTime);',
'    }',
'}',
'',
unistr('// Funci\00F3n para iniciar el temporizador de trabajo'),
'function startPomodoro() {',
'    isRunning = true;',
'    document.getElementById("pomodoro-status").textContent = "Tiempo de estudio"; // Cambiar estado a estudio',
'    var timeLeft = totalTime;',
'    pomodoroInterval = setInterval(function() {',
'        var minutes = Math.floor(timeLeft / 60);',
'        var seconds = timeLeft % 60;',
'        document.getElementById("pomodoro-timer").textContent = ',
'            (minutes < 10 ? "0" : "") + minutes + ":" + ',
'            (seconds < 10 ? "0" : "") + seconds;',
'        timeLeft--;',
'',
'        if (timeLeft < 0) {',
'            clearInterval(pomodoroInterval);',
unistr('            startBreak(); // Iniciar el temporizador de descanso autom\00E1ticamente'),
'        }',
'    }, 1000);',
'}',
'',
unistr('// Funci\00F3n para iniciar el temporizador de descanso'),
'function startBreak() {',
'    document.getElementById("pomodoro-status").textContent = "Hora del descanso"; // Cambiar estado a descanso',
'    var timeLeft = breakTime; // Usar el tiempo de descanso',
'    pomodoroInterval = setInterval(function() {',
'        var minutes = Math.floor(timeLeft / 60);',
'        var seconds = timeLeft % 60;',
'        document.getElementById("pomodoro-timer").textContent = ',
'            (minutes < 10 ? "0" : "") + minutes + ":" + ',
'            (seconds < 10 ? "0" : "") + seconds;',
'        timeLeft--;',
'',
'        if (timeLeft < 0) {',
'            clearInterval(pomodoroInterval);',
unistr('            startPomodoro(); // Volver a iniciar el temporizador de trabajo autom\00E1ticamente'),
'        }',
'    }, 1000);',
'}',
'',
unistr('// Funci\00F3n para restablecer el temporizador y detener el bucle'),
'function resetPomodoro() {',
'    clearInterval(pomodoroInterval);',
unistr('    totalTime = durationInMinutes * 60; // Reiniciar el tiempo de la sesi\00F3n'),
'    document.getElementById("pomodoro-timer").textContent = formatTime(totalTime);',
'    document.getElementById("pomodoro-status").textContent = "Tiempo de estudio"; // Reiniciar a estado de estudio',
'    isRunning = false;',
'}',
'',
unistr('// Funci\00F3n para formatear el tiempo en minutos y segundos'),
'function formatTime(seconds) {',
'    var minutes = Math.floor(seconds / 60);',
'    var seconds = seconds % 60;',
'    return (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38852113256619176899)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38671180744641286822)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38671065047146286768)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38671643540780286855)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38852329421501481201)
,p_plug_name=>unistr('\200E ')
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38671168358422286816)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="pomodoro-timer" style="font-size: 48px; text-align: center; margin-top: 20px;">',
'    25:00',
'</div>',
'',
unistr('<!-- A\00F1adir un nuevo elemento para mostrar el estado del temporizador -->'),
'<div id="pomodoro-status" style="font-size: 24px; padding-top: 1rem; text-align: center; margin-top: 10px;">',
'    Tiempo de estudio',
'</div>',
'',
unistr('<!-- Selector de tiempo para la sesi\00F3n de trabajo -->'),
'<div style="text-align: center; margin-top: 20px;">',
unistr('    <label for="session-time">Duraci\00F3n de la sesi\00F3n:</label>'),
'    <select id="session-time" onchange="updateDuration()">',
'        <option value="25">25 minutos</option>',
'        <option value="15">15 minutos</option>',
'        <option value="5">5 minutos</option>',
'    </select>',
'</div>',
'',
'<!-- Botones para iniciar y restablecer -->',
'<div style="text-align: center; margin-top: 20px;">',
'    <button type="button" onclick="startPomodoro()">Iniciar</button>',
'    <button type="button" onclick="resetPomodoro()">Restablecer</button>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
