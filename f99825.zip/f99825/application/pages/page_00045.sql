prompt --application/pages/page_00045
begin
--   Manifest
--     PAGE: 00045
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38646529912397976151
,p_default_application_id=>99825
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PATASAURIOS'
);
wwv_flow_imp_page.create_page(
 p_id=>45
,p_name=>'Crear Quizz'
,p_alias=>'CREAR-QUIZZ'
,p_step_title=>'Crear Quizz'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38929845082879820274)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38671180744641286822)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38671065047146286768)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38671643540780286855)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38929845719610820276)
,p_plug_name=>'Crear Quizz'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38671158542927286811)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'TOPICS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_prn_page_header=>'Crear Quizz'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38862079280024568338)
,p_name=>'Seleccionar Temas'
,p_source_type=>'SQL_EXPRESSION'
,p_source_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'0',
''))
,p_data_type=>'NUMBER'
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38929847037891820277)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(38929848086075820278)
,p_name=>'NOMBRE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOMBRE'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Nombre'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_enable_pivot=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(38929846221389820276)
,p_internal_uid=>38929846221389820276
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(38929846604654820276)
,p_interactive_grid_id=>wwv_flow_imp.id(38929846221389820276)
,p_static_id=>'389298467'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(38929846828387820276)
,p_report_id=>wwv_flow_imp.id(38929846604654820276)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(38929847470427820277)
,p_view_id=>wwv_flow_imp.id(38929846828387820276)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(38929847037891820277)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(38929848408160820278)
,p_view_id=>wwv_flow_imp.id(38929846828387820276)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(38929848086075820278)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(38932644509687564734)
,p_view_id=>wwv_flow_imp.id(38929846828387820276)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(38862079280024568338)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38862079343610568339)
,p_button_sequence=>30
,p_button_name=>'Create_quizz'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38671642083014286854)
,p_button_image_alt=>'Create Quizz'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38862079400041568340)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Seleccion Temas'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_tema_id NUMBER;',
'BEGIN',
'    -- Borrar registros previos en la tabla temporal si la usas',
'    DELETE FROM TEMP_QUIZ;',
'',
'    -- APEX_APPLICATION.G_F01 contiene los valores seleccionados del checkbox',
'    FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        v_tema_id := APEX_APPLICATION.G_F01(i);',
'        ',
'        -- Seleccionar preguntas aleatorias para el tema seleccionado',
'        FOR rec IN (SELECT ID, PREGUNTA, RESPUESTA_CORRECTA',
'                    FROM QUESTIONS',
'                    WHERE TEMA_ID = v_tema_id',
'                    ORDER BY DBMS_RANDOM.VALUE',
'                    FETCH FIRST 5 ROWS ONLY) LOOP',
'            -- Insertar preguntas seleccionadas en la tabla temporal',
'            INSERT INTO TEMP_QUIZ (TEMA_ID, PREGUNTA, RESPUESTA_CORRECTA)',
'            VALUES (v_tema_id, rec.PREGUNTA, rec.RESPUESTA_CORRECTA);',
'        END LOOP;',
'    END LOOP;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38862079400041568340
);
wwv_flow_imp.component_end;
end;
/
